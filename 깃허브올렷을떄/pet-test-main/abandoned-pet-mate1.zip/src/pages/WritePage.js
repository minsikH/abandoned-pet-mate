import React from "react";
import Write from "../component/Write";

const WritePage = () => {
  return (
    <div>
      <Write />
    </div>
  );
};

export default WritePage;
